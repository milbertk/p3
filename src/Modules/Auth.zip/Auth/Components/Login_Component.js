import React, { useState } from "react";
import { toast } from "react-toastify";
import {
  FaGoogle,
  FaFacebookF,
  FaMicrosoft,
  FaApple,
} from "react-icons/fa";
import {
  browserLocalPersistence,
  setPersistence,
  signInWithEmailAndPassword,
  signInWithPopup,
  signInWithRedirect,
} from "firebase/auth";

import "./Login_Component.scss";
import BasicModal from "../../../Shared/Components/BasicModal/BasicModal";
import Register_Component from "./Register_Component";

import LoginUserService from "../Services/LoginUserService";
import {
  auth,
  googleProvider,
  facebookProvider,
  microsoftProvider,
} from "../../../Shared/firebase/firebase";

function Login_Component(props) {
  const { setRefreshCheckLogin, t } = props;

  const [showRegister, setShowRegister] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const tr = (key, fallback) => {
    try {
      const value = typeof t === "function" ? t(key) : null;
      return value && value !== key ? value : fallback;
    } catch {
      return fallback;
    }
  };

  const friendlyFirebaseError = (error) => {
    const code = error?.code || "";

    switch (code) {
      case "auth/invalid-email":
        return tr("login.invalidEmail", "The email address is not valid.");
      case "auth/user-disabled":
        return tr("login.userDisabled", "This account has been disabled.");
      case "auth/user-not-found":
        return tr("login.userNotFound", "No account found with this email.");
      case "auth/wrong-password":
      case "auth/invalid-credential":
        return tr("login.wrongPassword", "Incorrect email or password.");
      case "auth/too-many-requests":
        return tr(
          "login.tooManyRequests",
          "Too many attempts. Try again later."
        );
      case "auth/popup-closed-by-user":
        return tr("login.popupClosed", "Sign-in window was closed.");
      default:
        return error?.message || tr("login.loginError", "Login failed.");
    }
  };

  const validate = () => {
    if (!email.trim() || !password) {
      toast.error(tr("login.emptyLogin", "All fields are required."));
      return false;
    }
    const emailOk = /\S+@\S+\.\S+/.test(email.trim());
    if (!emailOk) {
      toast.error(tr("login.invalidEmail", "The email address is not valid."));
      return false;
    }
    return true;
  };

  const finalizeLogin = async (firebaseToken) => {
    const loginService = new LoginUserService();
    const result = await loginService.login(firebaseToken);

    if (result?.error) {
      throw new Error(result.message || tr("login.loginError", "Login failed."));
    }

    toast.success(tr("login.loginSuccess", "Signed in successfully."));

    // IMPORTANTE: usar el setter functional para que SIEMPRE cambie el valor
    // y dispare el useEffect en App.js. Si hacemos setRefreshCheckLogin(true)
    // y ya está en true, React no detecta cambio → no se re-chequea el login.
    if (typeof setRefreshCheckLogin === "function") {
      setRefreshCheckLogin((prev) => !prev);
    }
  };

  const handleEmailLogin = async (e) => {
    e?.preventDefault?.();
    if (submitting) return;
    if (!validate()) return;

    try {
      setSubmitting(true);

      await setPersistence(auth, browserLocalPersistence);

      const userCredential = await signInWithEmailAndPassword(
        auth,
        email.trim(),
        password
      );
      const firebaseToken = await userCredential.user.getIdToken();

      await finalizeLogin(firebaseToken);
    } catch (error) {
      console.error("Email login error:", error);
      toast.error(friendlyFirebaseError(error));
    } finally {
      setSubmitting(false);
    }
  };

  const handleSocialLogin = async (providerName) => {
    if (submitting) return;

    if (providerName === "Apple") {
      toast.info(tr("login.appleComingSoon", "Apple sign-in coming soon."));
      return;
    }

    const providerMapping = {
      Google: googleProvider,
      Facebook: facebookProvider,
      Microsoft: microsoftProvider,
    };

    const provider = providerMapping[providerName];
    if (!provider) {
      console.error("Unsupported provider:", providerName);
      return;
    }

    if (typeof provider.setCustomParameters === "function") {
      provider.setCustomParameters({ prompt: "select_account" });
    }

    try {
      setSubmitting(true);

      await setPersistence(auth, browserLocalPersistence);

      const userCredential = await signInWithPopup(auth, provider);
      const firebaseToken = await userCredential.user.getIdToken();

      await finalizeLogin(firebaseToken);
    } catch (error) {
      if (
        error?.code === "auth/popup-blocked" ||
        error?.code === "auth/popup-closed-by-user"
      ) {
        console.warn("Popup failed, falling back to redirect...");
        try {
          await signInWithRedirect(auth, provider);
        } catch (redirectErr) {
          console.error("Redirect login error:", redirectErr);
          toast.error(tr("login.socialLoginError", "Social sign-in failed."));
        }
      } else {
        console.error("Social login error:", error);
        toast.error(friendlyFirebaseError(error));
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="login-design">
      <section className="login-design__image">
        <div className="login-design__image-content">
          <span className="login-design__badge">
            {t("login.businessPlatform")}
          </span>

          <h1>{t("login.manageCompanyTitle")}</h1>

          <p>{t("login.manageCompanyDescription")}</p>
        </div>
      </section>

      <section className="login-design__panel">
        <div className="login-design__mobile-header">
          <div className="login-design__mobile-header-content">
            <span className="login-design__badge">
              {t("login.businessPlatform")}
            </span>
            <h3>{t("login.manageCompanyTitle")}</h3>
          </div>
        </div>

        <form className="login-design__card" onSubmit={handleEmailLogin}>
          <h2>{t("login.signIn")}</h2>

          <p className="login-design__subtitle">
            {t("login.signInSubtitle")}
          </p>

          <div className="login-design__field">
            <label>{t("login.email")}</label>
            <input
              type="email"
              placeholder={t("login.emailPlaceholderLogin")}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={submitting}
              autoComplete="email"
            />
          </div>

          <div className="login-design__field">
            <label>{t("login.password")}</label>
            <input
              type="password"
              placeholder={t("login.passwordPlaceholder")}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={submitting}
              autoComplete="current-password"
            />
          </div>

          <button
            className="login-design__primary"
            type="submit"
            disabled={submitting}
          >
            {submitting
              ? tr("login.signingIn", "Signing in...")
              : t("login.signIn")}
          </button>

          <div className="login-design__divider">
            <span>{t("login.orContinueWith")}</span>
          </div>

          <div className="login-design__social-grid">
            <button
              type="button"
              onClick={() => handleSocialLogin("Google")}
              disabled={submitting}
            >
              <FaGoogle /> {t("login.google")}
            </button>

            <button
              type="button"
              onClick={() => handleSocialLogin("Facebook")}
              disabled={submitting}
            >
              <FaFacebookF /> {t("login.facebook")}
            </button>

            <button
              type="button"
              onClick={() => handleSocialLogin("Microsoft")}
              disabled={submitting}
            >
              <FaMicrosoft /> {t("login.microsoft")}
            </button>

            <button
              type="button"
              onClick={() => handleSocialLogin("Apple")}
              disabled={submitting}
            >
              <FaApple /> {t("login.apple")}
            </button>
          </div>

          <p className="login-design__register">
            {t("login.dontHaveAccount")}{" "}
            <button
              type="button"
              className="login-design__register-button"
              onClick={() => setShowRegister(true)}
              disabled={submitting}
            >
              {t("login.createAccount")}
            </button>
          </p>
        </form>
      </section>

      <BasicModal show={showRegister} setShow={setShowRegister}>
        <Register_Component
          setRefreshCheckLogin={setRefreshCheckLogin}
          t={t}
        />
      </BasicModal>
    </div>
  );
}

export default Login_Component;